   //Chapter 1

// 1.Write a script to greet your website visitor using JS alert
// box.

// var a = "Hy Nice to meet you";
// alert(a);


// 2. Write a script to display following message on your web
// page:

// var a = "Error! Please enter a valid password";
// alert(a);


// 3. Write a script to display following message on your web
// page: (Hint : Use line break)

// var a = "Welcome JS Land.. \n Happy Coding!";
// alert(a);


// 4. Write a script to display following messages in sequence:

// var a = "Welcome to JS...";
// var b = "Happy Coding! \n Prevent this page from creating additional dialogs.";
// alert(a);
// alert(b);


// 5. Generate the following message through browser’s
// developer console:

// console.log = "Hello... I can run JS through my web browser's console";
// alert(console.log);


//6. Make use of alerts in your new/existing HTML & CSS
//project.




// 7. Practice placement of <script></script> element in
// following sections of your project in exercise 6:
// a. Head
// b. Body (before your page’s HTML)
// c. Body (inside your page’s HTML)
// d. Body (after your page’s HTML)




                                              //Chapter 2

// 1. Declare a variable called username.      

// var a = "Misbah";
// alert(a);


// 2. Declare a variable called myName & assign to it a string
// that represents your Full Name.

// var myName = "Misbah";
// var fullName = "Misbah A.Razzak";
// alert(myName);
// alert(fullName);


// 3. Write script to
// a) Declare a JS variable, titled message.
// b) Assign “Hello World” to variable message
// c) Display the message in alert box.

// document.title = "Hello World";
// alert(document.title);


// 4. Write a script to save student’s bio data in JS variables and
// show the data in alert boxes.

// var Name = "Name \n Misbah";
// var fatherName = "Father Name \n Abdul RAzzak";
// var dateofBirth = "11-july-2000";
// var religion = "Islam";
// var nationalty = "Pakistani";
// alert(Name);
// alert(fatherName);
// alert(dateofBirth);
// alert(religion);
// alert(nationalty);



// 5. Write a script to display the following alert using one JS
// variable:

// var script = "PIZZA \n PIZZ \n PIZ \n PI \n P";
// alert(script);


// 6. Declare a variable called email and assign to it a string that
// represents your Email Address(e.g. example@example.com).
// Show the blow mentioned message in an alert box.(Hint: use
// string concatenation)

// var email = "My Email is" + " " + "misbahmemon1107@gmail.com" ;
// alert(email);


// 7. Declare a variable called book & give it the value “A
// smarter way to learn JavaScript”. Display the following
// message in an alert box:

// var book ="I am trying to learn the Book A smarter way to learn JavaScript";
// alert(book);


// 8. Write a script to display this in browser through JS

// document.write("Yah! I can write HTML contant through JavaScript ");


// 9. Store following string in a variable and show in alert and
// browser through JS

// var designe = "“▬▬▬▬▬▬▬▬▬ஜ۩۞۩ஜ▬▬▬▬▬▬▬▬▬”";
// alert(designe);





                                              // Chapter 3

// 1. Declare a variable called age & assign to it your age. Show
// your age in an alert box.

// var age = "I am 20 year old ";
// alert(age);


// 2. Declare & initialize a variable to keep track of how many
// times a visitor has visited a web page. Show his/her
// number of visits on your web page. For example: “You
// have visited this site N times”.

//var visit = "you have visited this sit";
//var num = "20";
//var message = ' time';
//alert(visit + " " + num + " " + message);



// 3. Declare a variable called birthYear & assign to it your
// birth year. Show the following message in your browser:

// var birthYear ="11-july-2000";
// document.write("My Date of birth is" + " " + birthYear + " <br>" + "Data type of my declared variable is number");


// 4. A visitor visits an online clothing store
// www.xyzClothing.com . Write a script to store in variables
// the following information:
// a. Visitor’s name
// b. Product title
// c. Quantity i.e. how many products a visitor wants to
// order
// Show the following message in your browser: “John
// Doe ordered 5 T-shirt(s) on XYZ Clothing store”.

// var name = prompt("Visitor's name");
// alert(name);

// var product = "XYZ";
// alert(product);

// var Quantity = prompt("How many product you want to order");
// alert(Quantity);

// document.write("“John Doe ordered 5 T-shirt(s) on XYZ Clothing store”.")


                                            //Chapter 4

// 1. Declare 3 variables in one statement.

// var variable1 = "Hello World";
// var variable2 = "The world is very bueatiful";
// var variable3 = "I want to become a web developer";
// alert(variable1);
// alert(variable2);
// alert(variable3);


// 2. Declare 5 legal & 5 illegal variable names.

        // 5 legal variable names.
// var fatherName = "A.Razzak";
// var father_name = "A.Razzak";
// var $name = "Misbah";
// var name = "Misbah";
// var _name = "Misbah";

         // 5 illegal variable names.
// var var = "Name";
// var if = "Name";
// var 1name = "Misbah";
// var father name = "A.Razzak";
// var for = "name";


// 3. Display this in your browser
// a) A heading stating “Rules for naming JS variables”
// b) Variable names can only contain ______, ______,
// ______ and ______.
// For example $my_1stVariable
// c) Variables must begin with a ______, ______ or
// _____. For example $name, _name or name
// d) Variable names are case _________
// e) Variable names should not be JS _________

// var a = document.write("A heading stating “Rules for naming JS variables”");
// var b = document.write("Variable names can only contain numbers, $, and _, For example $my_1stVariable ");
// var c = document.write("Variables must begin with a letters, $ or _____. For example $name, _name or name");
// var d = document.write("Variable names are case sensitive");
// var e = document.write("Variable names should not be JS Keywords");


                                                  //Chapter 5

// 1. Write a program that take two numbers & add them in a
//  new variable. Show the result in your browser.

// var value1 = 3;
// var value2 = 5;
// var sum = value2 + value2;
// alert(sum);
// document.write("sum of " + " " + sam + " " + " and " + " " + value1 + " " + " is " + " " + value2);


// 2. Repeat task1 for subtraction, multiplication, division &
// modulus.

         // Subtraction
// var num1 = 3;
// var num2 = 5;
// var sum = num1 - num2;
// alert(sum);
// document.write("Subtraction of 3 - 5 is -2");

         //multiplication
// var num1 = 3;
// var num2 = 5;
// var sum = num1 * num2;
// alert(sum);
// document.write("Multiplication of 3 * 5 is 15");

        //Division
// var num1 = 3;
// var num2 = 5;
// var sum = num1 / num2;
// alert(sum);
// document.write("Division of 3 / 5 is 0.6 ");

        //Addition
// var num1 = 10;
// var num2 = 5;
// var sum = num1 + num2;
// alert(sum);
// document.write("Adition of 10 + 5 is 15 ");


// 3. Do the following using JS Mathematic Expressions
// a. Declare a variable.
// b. Show the value of variable in your browser like “Value
// after variable declaration is: ??”.
// c. Initialize the variable with some number.
// d. Show the value of variable in your browser like “Initial
// value: 5”.
// e. Increment the variable.
// f. Show the value of variable in your browser like “Value
// after increment is: 6”.
// g. Add 7 to the variable.
// h. Show the value of variable in your browser like “Value
// after addition is: 13”.
// i. Decrement the variable.
// j. Show the value of variable in your browser like “Value
// after decrement is: 12”.
// k. Show the remainder after dividing the variable’s value
// by 3.
// l. Output : “The remainder is : 0”.

// var value;
// document.write("Value after variable declaration is" + " " + value +"<br>");

// var initial_value = 5;
// document.write("Initial value is:" + " " +  initial_value +"<br>");

// var value = ++ initial_value;
// document.write("Value after increment is:" + " " + value +"<br>");

// var a = 5 ;
// var b = 2;
// var c = value;
// var d = a + 2 + value;
// document.write("Value after addition is:" + " " + d + "<br>");

// var a = --d ;
// document.write("Value after decrement is:" + " " + a + "<br>");

// var remainder = initial_value % value;
// document.write("The remainder is:" + " " + remainder );


// 4. Cost of one movie ticket is 600 PKR. Write a script to
// store
// ticket price in a variable & calculate the cost of buying 5
// tickets
// to a movie. Example output:

//  var buyNum = prompt("Enter Number of tickets");
//  var text = "Your total cost is"
//  var sum = text + buyNum * 600 ;
//  alert(sum);
//  document.write("Total cost to buy 5 tickets to movie is"+ " " + sum + " " + "PKR")


// 5. Write a script to display multiplication table of any
// number in your browser. E.g

//  var table=prompt("enter table number","5")
//   for(var a=1; a<11;a++){
//       document.write(table+"x "+a+" = "+a*table + "<br>")
//   }


// 6. The Temperature Converter: It’s hot out! Let’s make a
// converter based on the steps here.
// a. Store a Celsius temperature into a variable.
// b. Convert it to Fahrenheit & output “NNoC is NNoF”.
// c. Now store a Fahrenheit temperature into a variable.
// d. Convert it to Celsius & output “NNoF is NNoC”.

// var Celsius=prompt("Enter Celsius");
// document.write(Celsius+"C is " +(Celsius*9/5+32) +"F" );

// var Fahrenheit=prompt("Enter Celsius");
// document.write(Fahrenheit+"F is " +(Fahrenheit-32)*5/9 +"C" );


// 7. Write a program to implement checkout process of a
// shopping cart system for an e-commerce website. Store
// the following in variables
// a. Price of item 1
// b. Price of item 2
// c. Ordered quantity of item 1
// d. Ordered Quantity of item 2
// e. Shipping charges
// Compute the total cost & show the receipt in your browser.

// var quantity = +prompt("Enter quantity");
// var shippingCharging = 100;
// var prceOfitem = 500;
// document.write("Price of item " + " " + prceOfitem + "<br>" + "quantity of item " + " " + quantity + "<br>" + "shippingCharging " + " " + shippingCharging + " <br>" + "Total cost of your order is " + " "+ (quantity*prceOfitem+shippingCharging));


// 8. Store total marks & marks obtained by a student in 2
// variables. Compute the percentage & show the result in
// your browser

// var marks = prompt("Enter your total marks");
// var marksObtained = prompt("Enter your Obtained MArks");
// document.write("Total Marks:"+ marks + "<br>" + "Marks Obtained:" + marksObtained + "<br>" + "Percentage:" + marks / marksObtained);


// 9. Assume we have 10 US dollars & 25 Saudi Riyals. Write a
// script to convert the total currency to Pakistani Rupees.
// Perform all calculations in a single expression.
// (Exchange rates : 1 US Dollar = 104.80 Pakistani Rupee
// and 1 Saudi Riyal = 28 Pakistani Rupee)

// var quantityOfDoller = prompt("Enter US doller");
// var quantityOfRiyals = prompt("Enter saudi riyals ");
// var doller = 104.80;
// var riyals = 28;
// document.write("Total Currency of  PKR"  +  (quantityOfDoller * 104.80 + quantityOfRiyals * 28) );


// 10. Write a program to initialize a variable with some
// number and do arithmetic in following sequence:
// a. Add 5
// b. Multiply by 10
// c. Divide the result by 2
// Perform all calculations in a single expression

// var variable = "sum";
// var a = 5;
// var b = 10;
// var c = 2;
// document.write( variable + a * b / c);


// 11. The Age Calculator: Forgot how old someone is?
// Calculate it!
// a. Store the current year in a variable.
// b. Store their birth year in a variable.
// c. Calculate their 2 possible ages based on the stored
// values.

// var currentYear = prompt("Enter Current Year");
// var birthOfdate = prompt("Enter your Birth date");
// document.write("Your Age is " + currentYear % birthOfdate);


// 12. The Geometrizer: Calculate properties of a circle.
// a. Store a radius into a variable.
// b. Calculate the circumference based on the radius, and
// output “The circumference is NN”.
// (Hint : Circumference of a circle = 2 π r , π = 3.142)
// Calculate the area based on the radius, and output “The
//area is NN”. (Hint : Area of a circle = π r2, π = 3.142)

// var radius = 40;
// var π = 6.284;
// document.write("Radius of a Circle:" + radius + "<br>" + "The circumference is:" + π +"<br>" + "The Area is :" + π * radius );


// 13.The Lifetime Supply Calculator: Ever wonder how
// much a “lifetime supply” of your favorite snack is?
// Wonder no more.
// a. Store your favorite snack into a variable
// b. Store your current age into a variable.
// c. Store a maximum age into a variable.
// d. Store an estimated amount per day (as a number).
// e. Calculate how many would you eat total for the rest of
// your life.
// Output the result to the screen like so: “You will need
// NNNN to last you until the ripe old age of NN”.

//  var currentAge=15;
//  var maximumAge=65; 
//  var amount=3;
//  document.write("Favourit snaks: choclate chip" + "<br>" +"current age " + currentAge + "<br>" + "maximumAge" + maximumAge + "<br>" + "Amount of snak totalMarkes day" + amount + "<br>" + "You will need " + (maximumAge-currentAge)*amount + " coclate chip to last the ripe olad age of " + maximumAge);


                                    // Chapter 6-9

//  1. Write a program to take a number in a variable, do the
//  required arithmetic to display the following result in your
//   browser:

// var num = 11;
// document.write("Result" + "<br>" + "The value is " + " " + num + "<br>" + "<br>" );
// var a = 11;
// var b = ++a;
// alert(b);
// document.write("The value of ++a is" + " " + b + "<br>" + "Now the value of a is 12" + "<br>" + "<br>");

// var a = 11;
// var b = a++;
// alert(b);
// document.write("The value of a++ is" + " " + b + "<br>" + "Now the value of a is 11" + "<br>" + "<br>");

// var a = 11;
// var b = --a;
// alert(b);
// document.write("The value of --a is" + " " + b + "<br>" + "Now the value of a is 10" + "<br>" + "<br>");

// var a = 11;
// var b = a--;
// alert(b);
// document.write("The value of a-- is" + " " + b + "<br>" + "Now the value of a is 11" + "<br>" + "<br>");


// 2. What will be the output in variables a, b & result after
// execution of the following script:
// var a = 2, b = 1;
// var result = --a - --b + ++b + b--;
// Explain the output at each stage:
// --a;
// --a - --b;
// --a - --b + ++b;
// --a - --b + ++b + b--;

// var a = 2;
// var b = --a;
// alert(b);
// document.write("Stage 1" + "<br>" +"The value of a is" + " " + b + "<br>" + "<br>")       

// var a = 2;
// var b = 1;
// var c = --a - --b;
// alert(c);
// document.write("Stage 2" + "<br>" +"The value of --a - --b is" + " " + c + "<br>" + "<br>")       

// var a = 2;
// var b = 1;
// var c = --a - --b + ++b;
// alert(c);
// document.write("Stage 3" + "<br>" +"The value of --a - --b + ++b is" + " " + c + "<br>" + "<br>")       

// var a = 2;
// var b = 1;
// var c = --a - --b + ++b + b--;
// alert(c);
// document.write("Stage 4" + "<br>" +"The value of --a - --b + ++b + b--; is" + " " + c + "<br>" + "<br>")       


// 3. Write a program that takes input a name from user &
// greet the user.

//  var name = prompt ("What is your name?");
//  var result = "Hello" + " " + name + " " + "Welcome to our Website"  ;
//  alert(result);


// 5. Write a program to take input a number from user &
// display it’s multiplication table on your browser. If user
// does not enter a new number, multiplication table of 5
// should be displayed by default.

// var table=prompt("enter table number","5");
//  for(var a=1; a<11;a++){
//      document.write(table+"x "+a+" = "+a*table + "<br>");
//  }


// 6. Take
// a) Take three subjects name from user and store them in 3
// different variables.
// b) Total marks for each subject is 100, store it in another
// variable.
// c) Take obtained marks for first subject from user and
// stored it in different variable.
// d) Take obtained marks for remaining 2 subjects from user
// and store them in variables.
// e) Now calculate total marks and percentage and show the
// result in browser like this.(Hint: user table)

// document.write ("Subject  TotalMarks ObtainedMarks  Percentage" + "<br>")
// var engl = "English";
// var math = "Math";
// var urdu = "Urdu";
// var TotalMark = 100;
// var obtEng = 54;
// var obtMath = 54;
// var obtUrdu = 48;
// var engper=(obtEng/TotalMark*100);
//  var urduper=(obtUrdu/TotalMark*100);
//  var mathper=(obtMath/TotalMark*100);
//  var obttotal=(obtEng+obtMath+obtUrdu);
// document.write(engl + " "+ TotalMark + "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp  " + obtEng+ "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp "+engper+"%"+"<br>");
// document.write(urdu + " &nbsp;&nbsp;&nbsp;&nbsp "+ TotalMark + "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp  "  + obtUrdu+ "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp  "  +urduper+"%"+"<br>");
// document.write(math + "&nbsp;&nbsp;&nbsp;&nbsp  "+ TotalMark + "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp  " + obtMath+ "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp  "  +mathper+"%"+"<br>" + "<br>");
// document.write("ToTal Marks" +"&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"+(TotalMark*3)+ "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp  "  +obttotal+  "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp  "  +(obttotal/300*100)+"%");


                                                                 // Chapter 9-11

        
//  1. Write a program to take “city” name as input from user. If
// user enters “Karachi”, welcome the user like this:
// “Welcome to city of lights”

//  var input = prompt ("Enter your city Name");
//  if ("karachi" === input){
//         alert ("Welcome to city of lights");

//  }


// 2. Write a program to take “gender” as input from user. If the
// user is male, give the message: Good Morning Sir. If the
// user is female, give the message: Good Morning Ma’am.
 
// var input = prompt("Enter your Gender");
// if ("male" ===input){
//         alert ("Good Morning Sir.");
// }
// else if ("female" ===input){
//         alert("Good Morning Ma'am.")
// }


// 3. Write a program to take input color of road traffic signal
// from the user & show the message according to this table:

// var input = prompt("Enter Color of traffic signal");
// if("red" === input){
//         alert("Must Stop");
// }
// else if ("yellow" === input){
//         alert("Ready to Move");
// }
// else if ("green"){
//         alert("Move now");
// }


// 4. Write a program to take input remaining fuel in car (in
// litres) from user. If the current fuel is less than 0.25litres,
// show the message “Please refill the fuel in your car”

// var input = prompt("Enter fuel in Car")
// if(0.25 >= input){
//         alert("“Please refill the fuel in your car”")
// }


// 5. Run this script, & check whether alert message would be
// displayed or not. Record the outputs.

// var a = 4;
// if (++a === 5){
// alert("given condition for variable a is true");
// }

// var b = 82;
// if (b++ === 83){
// alert("given condition for variable b is true");
// }

// var c = 12;
// if (c++ === 13){
// alert("condition 1 is true");
// }
// if (c === 13){
// alert("condition 2 is true");
// }
// if (++c < 14){
// alert("condition 3 is true");
// }
// if(c === 14){
// alert("condition 4 is true");
// }

// var materialCost = 20000;
// var laborCost = 2000;
// var totalCost = materialCost + laborCost;
// if (totalCost === laborCost + materialCost){
// alert("The cost equals");
// }

// if (true){
// alert("True");
// }
// if (false){
// alert("False");
// }

// if("car" < "cat"){
//         alert("car is smaller than cat");
//         }


// 6. Write a program to take input the marks obtained in three
// subjects & total marks. Compute & show the resulting
// percentage on your page. Take percentage & compute
// grade as per following table:

// var totalMarkes=prompt("enter total markes")
// var obtMarkes=prompt("enter obt markes")
// var per=obtMarkes/totalMarkes*100
// if(per >=80 && per <= 100){
//     document.write("total markes ",totalMarkes,"<br> ","obtMarkes ",obtMarkes,"<br>","persentage ",per,"%","<br>","grad A+","<br>","remarks Exellent")
// }
// else if(per >=70 && per <= 80){
//     document.write("total markes ",totalMarkes,"<br> ","obtMarkes ",obtMarkes,"<br>","persentage ",per,"%","<br>","grad A","<br>","remarks Good")
// }
// else if(per >=60 && per <= 70){
//     document.write("total markes ",totalMarkes,"<br> ","obtMarkes ",obtMarkes,"<br>","persentage ",per,"%","<br>","grad B","<br>","remarks need to improve")
// }
//  else if(per >=50 && per <= 60){
//     document.write("total markes ",totalMarkes,"<br> ","obtMarkes ",obtMarkes,"<br>","persentage ",per,"%","<br>","grad C","<br>","remarks Sorry")
// }
// else if(per >=40 && per <= 50){
//     document.write("total markes ",totalMarkes,"<br> ","obtMarkes ",obtMarkes,"<br>","persentage ",per,"%","<br>","grad D","<br>","remarks Sorry")
// }
// else if(per >=33 && per <= 40){
//     document.write("total markes ",totalMarkes,"<br> ","obtMarkes ",obtMarkes,"<br>","persentage ",per,"%","<br>","grad E","<br>","remarks Sorry")
// }
// else if(per >=0 && per <= 33){
//     document.write("total markes ",totalMarkes,"<br> ","obtMarkes ",obtMarkes,"<br>","persentage ",per,"%","<br>","grad C","<br>","remarks Sorry")
// }
// else{
//     alert("writw corect persentage")
// }


// 7. Guess game:
// Store a secret number (ranging from 1 to 10) in a variable.
// Prompt user to guess the secret number.
// a. If user guesses the same number, show “Bingo! Correct
// answer”.
// b. If the guessed number +1 is the secret number, show
// “Close enough to the correct answer”.

// var num = prompt("Enter a number");
// if( num >=1 && num <= 10 ){
//         alert("Bingo! Correct answer");
// }
// else if ( num >=10 && num <= 11){
//         alert("“Close enough to the correct answer”.");
// }
// else ( num >= 12); {
//         alert("WRONG");
// }


// 8. Write a program to check whether the given number is
// divisible by 3. Show the message to the user if the number
// is divisible by 3.

// var input = prompt("Enter value");
// alert(input / 3);


// 9. Write a program that checks whether the given input is an
// even number or an odd number.

// var input=prompt("Enter value")
// if(input%2==0){
//     alert("even")
// }
// else{
//     alert("odd")
// }


// 10. Write a program that takes temperature as input and
// shows a message based on following criteria
// a. T > 40 then “It is too hot outside.”
// b. T > 30 then “The Weather today is Normal.”
// c. T > 20 then “Today’s Weather is cool.”
// d. T > 10 then “OMG! Today’s weather is so Cool.”

// var input=prompt("enter temperture")
// if(input >=40){
//     alert(" “It is too hot outside.”")
// }
// else if(input >=30 && input <=40){
//     alert(" “The Weather today is Normal.”")
// }
// else if(input >=20 && input <=30){
//     alert("“Today’s Weather is cool.”")

// }else if (input >=10 && input <=20){
//     alert(" “OMG! Today’s weather is so Cool.”")
// }


// 11. Write a program to create a calculator for +,-,*, / & %
// using if statements. Take the following input:
// a. First number
// b. Second number
// c. Operation (+, -, *, /, %)
// Compute & show the calculated result to user.

// var value1 = +prompt("Enter First Value");
// var operation = prompt("Operation");
// var value2 = prompt("Enter Second Value");
// if (operation === "*" ){
// alert(value1 * value2);
// }
// else if (operation === "/" ){
//         alert(value1 / value2);
// }
// else if (operation === "%" ){
//         alert(value1 % value2);
// }
// else if (operation === "-"){
//         alert(value1 - value2);
// }
// else if(operation === "+"){
//         alert(value1 + value2);
// }
                                   //Chapter 12-13

// 1. Write a program that takes a character (number or string)
// in a variable & checks whether the given input is a
// number, uppercase letter or lower case letter. (Hint: ASCII
//  codes:- A=65, Z=90, a=97, z=122).

// ar input=prompt ("Enter alphbate")
// if(input >=A(65) && input <=Z(90)){
//     alert("upper case")
// }
// else if(input >=67 && input <=122){
//     alert("lower case")
// }
   

// 2. Write a JavaScript program that accept two integers and
// display the larger. Also show if the two integers are equal.

// var num1, num2;
// num1 = prompt("Input the First integer", "0");
// num2 = prompt("Input the second integer", "0");
                                                 
// if(parseInt(num1, 10) > parseInt(num2, 10)) 
//   { 
//   document.write("The larger of "+ num1+ " and "+ num2+ " is "+ num1+ ".");
//   }   
// else
//   if(parseInt(num2, 10) > parseInt(num1, 10)) 
//   {
//   document.write("The larger of "+ num1+" and "+ num2+ " is "+ num2+ ".");
//   }                  
// else
//   {
//    document.write("The values "+ num1+ " and "+num2+ " are equal.");
//   }


// 3. Write a program that takes input a number from user &
// state whether the number is positive, negative or zero.


// var number = prompt("Enter number");
// if ( number == 0 ){
//         alert("The Number is zero.");
// }
// else if ( number >= 0 ){
//         alert("The number is positive.");
// }
// else if ( number <= 0 ){
//         alert( "The number is negative" );
// }


// 4. Write a program that takes a character (i.e. string of
//  length 1) and returns true if it is a vowel, false otherwise

// var vowel = prompt("Enter alphabate");
// if ( vowel === "a"||vowel=="e"||vowel=="i"||vowel=="o"||vowel=="u"  ){ 
//         alert("True");
// }
// else {
//         alert("False")
// }


// 5. Write a program that
// a. Store correct password in a JS variable.
// b. Asks user to enter his/her password
// c. Validate the two passwords:
// i. Check if user has entered password. If not, then
// give message “ Please enter your password”
// ii. Check if both passwords are same. If they are
// same, show message “Correct! The password you
// entered matches the original password”. Show
// “Incorrect password” otherwise.
// var password = ("Misbah");
// console.log(password);
// var password = prompt ("Enter password");
// if ("Misbah" === password){
//         alert("Correct");
// }
//  else if ("Misbah" != password){
//          alert("“ Please enter your password”")
//  }


// 6. This if/else statement does not work. Try to fix it:

// var greeting = prompt("Enter time");
// var greeting;
// if (greeting <= 13) {
// alert ("Good day")
// }
// else if (greeting > 13) {
// alert("Good evening");
// }


// 7. Write a program that takes time as input from user in 24
// hours clock format like: 1900 = 7pm. Implement the
// following case using if, else & else if statements

// var time = prompt("Enter time and am and pm");
// if ( time === "01:00 pm" ){
//         alert( "13:00" )
// }
// else if ( time === "02:00 pm"){
//         alert("14:00")
// }
// else if ( time === "03:00 pm"){
//         alert("15:00")
// }

// else if ( time === "04:00 pm"){
//         alert("16:00");
// }

// else if ( time === "05:00 pm"){
//         alert("17:00");
// }
// else if ( time === "06:00 pm"){
//         alert("18:00");
// }
// else if ( time === "07:00 pm"){
//         alert("19:00");
// }
// else if ( time === "08:00 pm"){
//         alert("20:00");
// }
// else if ( time === "09:00 pm"){
//         alert("21:00");
// }
// else if ( time === "10:00 pm"){
//         alert("22:00");
// }
// else if ( time === "11:00 pm"){
//         alert("12:00");
// }
// else if ( time === "12:00 pm"){
//         alert("24:00");
// }






                 //Chapter 14-16

// 1. Declare an empty array using JS literal notation to store
// student names in future.

// var arr = [ ];
// console.log(arr);

// 2. Declare an empty array using JS object notation to store
// student names in future.

//  var a = [];
//  var b = new Array  ( ) ;
//  console.log(b);


// 3. Declare and initialize a strings array.

//  var string = [];
//  push = ["cow" , "fox" , "crow"];
//  document.write(push);


// 4. Declare and initialize a numbers array.

// var num = [];
// push = [2,3,4,5];
// document.write(push);

// 5. Declare and initialize a boolean array.

// var array = [];
//  push = [0 , 0.5 , 1 , "false", "" , "true"];
// document.write(push);

// 6. Declare and initialize a mixed array.

// var mixed_array = [1 , 2 , 3 , "one" , "two" , "three"];
// document.write(mixed_array);


// 7. Declare and Initialize an array and store available
// education qualifications in Pakistan (e.g. SSC, HSC, BCS,
// BS, BCOM, MS, M. Phil., PhD). Show the listed
// qualifications in your browser like:

// document.write("Qualification" + "<br>" + "<br>");
// var qualifications = ["SSC", "HSC", "BCS", "BS", "BCOM", "MS", "M.Phil.","PhD"];
// for (let i=0; i<=7; i++){
//     document.write(qualifications[i] + "<br>");
// }


// 8. Write a program to store 3 student names in an array.Take
// another array to store score of these three students.
// Assume that total marks are 500 for each student, display
// the scores & percentages of students like:

// var student = ["Micheal","Jhone","Tony"];
// var score = [320,230,480];
// var percentages = ["64%" ,"46%", "96%"];
// document.write("Score of" + " " + student[0]+" " + "is" + " " + score[0] +"." + " " + "percentages"+ " " + percentages[0] + "<br>");
// document.write("Score of" + " " + student[1]+" " + "is" + " " + score[1] +"." + " " + "percentages"+ " " + percentages[1] + "<br>");
// document.write("Score of" + " " + student[2]+" " + "is" + " " + score[2] +"." + " " + "percentages"+ " " + percentages[2] );


// 9. Initialize an array with color names. Display the array
// elements in your browser.

 //   var colorName = [ "Red","Green","Blue","Black","Pink" ];
 //   for(var i=0;i<=4;i++){
 //       document.write(colorName[i] +"<br>");
 //   }

// a. Ask the user what color he/she wants to add to the
// beginning & add that color to the beginning of the array.
// Display the updated array in your browser.

//    var color = ["White","Purple"];
// var want = prompt("Are you add the color at the begins [yes/no]");
// if(want === "yes"){
//     var i = prompt("Which Color you Add");
//     color.unshift(i);
//     document.write(color);
    
// }

// b. Ask the user what color he/she wants to add to the end
// & add that color to the end of the array. Display the
// updated array in your browser.

// var color = ["White","Purple"];
// var want = prompt("Are you add the color at the end [yes/no]");
// if(want === "yes"){
//     var i = prompt("Which Color you Add");
//     color.push(i);
//     document.write(color);
// }

// c. Add two more color to the beginning of the array.
// Display the updated array in your browser.

    //   var color = ["White","Purple"];
    // var i = prompt("Which 2 Colors you Add");
    // color.unshift(i);
    // document.write(color);

//     d. Delete the first color in the array. Display the updated
// array in your browser.
    
    //   var color = ["Pink","Red","White","Purple"];
    //   document.write(color + "<br>");
    //   var colors = ["Pink","Red","White","Purple"];
    // colors.shift(colors);
    // document.write(colors);

//     e. Delete the last color in the array. Display the updated
// array in your browser.


    //  var color = ["Pink","Red","White","Purple"];
    //    document.write(color + "<br>");
    //    var colors = ["Pink","Red","White","Purple"];
    //  colors.pop(colors);
    //  document.write(colors);

//     f. Ask the user at which index he/she wants to add a color
// & color name. Then add the color to desired
// position/index. . Display the updated array in your
// browser.
    
    //  var index = prompt("Which index position you add color");
    //  var colors = prompt("Enter Color Name");
    //  var color = ["Red","Green","Blue","Black","Pink" ];
    //  color.splice(index,0,colors);
    //  document.write(color );

//     g. Ask the user at which index he/she wants to delete
// color(s) & how many colors he/she wants to delete. Then
// remove the same number of color(s) from user-defined
// position/index. . Display the updated array in your
// browser.

//      var index = prompt("Which index position you delete color");
//      var num = prompt("Enter Color Name");
//      var color = ["Red","Green","Blue","Black","Pink" ];
//      color.splice(index,1);
//      document.write(color );



// 10. Write a program to store student scores in an array &
// sort the array in ascending order using Array’s sort
// method.

//  var students_scores = [320,230,480,120];
//  var order_score = [320,230,480,120];
//  order_score.sort();
//  document.write("Scores of Students" + " " + students_scores + "<br>" + "Orederd Scores of student " + order_score );


//  11. Write a program to initialize an array with city names.
//  Copy 3 array elements from cities array to selectedCities
//  array.

//  var city = ["karachi","Islamabad","Lahore","Hyderabad","Quatta"];
//  var copyCities = city.slice(1,4) ;
//  document.write("Cities list:" + "<br>" + city +"<br>"+"<br> " + "Selected cities list:" + "<br>"+ copyCities );



// 12. Write a program to create a single string from the
// below mentioned array:
// var arr = [“This ”, “ is ”, “ my ”, “ cat”];
// (Use array’s join method)

// var arr = ["This ", " is" ,  "my ",  "cat"];
// var join = arr.join(" ");
// document.write("Array:"+ "<br> " + arr + " <br>" + "<br>" + "String" + "<br> "+ join );


// 13. Create a new array. Store values one by one in such a way
// that you can access the values in the order in which they
// were stored. (FIFO-First In First Out)

//  var arry=["keyboard","mouse","printed","mointer"]

//  for(var i=0;i<=3;i++){
//       document.write("Out:"+"<br>"+arry[i]+"<br>")
//  }

//  14. Create a new array. Store values one by one in such a way
// that you can access the values in reverse order. (Last InFirst Out)

// var arry=["keyboard","mouse","printed","mointer"]

//    for(var i=3;i>=0;i--){
//         document.write("Out:"+"<br>"+arry[i]+"<br>")
//    }

//question 15 is on index page.

                //Tables 2 to 20


//       var table = 2;
//    for(var a=1; a<11;a++){
//        document.write(table+"x "+a+" = "+a*table + "<br>")
//    }
// document.write("<br>");

//    var table = 3;
//    for(var a=1; a<11;a++){
//        document.write(table+"x "+a+" = "+a*table + "<br>")
//    }
//    document.write("<br>");

//    var table = 4;
//    for(var a=1; a<11;a++){
//        document.write(table+"x "+a+" = "+a*table + "<br>")
//    }
//    document.write("<br>");

//    var table = 5;
//    for(var a=1; a<11;a++){
//        document.write(table+"x "+a+" = "+a*table + "<br>")
//    }
//    document.write("<br>");

//    var table = 6;
//    for(var a=1; a<11;a++){
//        document.write(table+"x "+a+" = "+a*table + "<br>")
//    }
//    document.write("<br>");

//    var table = 7;
//    for(var a=1; a<11;a++){
//        document.write(table+"x "+a+" = "+a*table + "<br>")
//    }
//    document.write("<br>");

//    var table = 8;
//    for(var a=1; a<11;a++){
//        document.write(table+"x "+a+" = "+a*table + "<br>")
//    }
//    document.write("<br>");

//    var table = 9;
//    for(var a=1; a<11;a++){
//        document.write(table+"x "+a+" = "+a*table + "<br>")
//    }
//    document.write("<br>");

//    var table = 10;
//    for(var a=1; a<11;a++){
//        document.write(table+"x "+a+" = "+a*table + "<br>")
//    }
//    document.write("<br>");

//    var table = 11;
//    for(var a=1; a<11;a++){
//        document.write(table+"x "+a+" = "+a*table + "<br>")
//    }
//    document.write("<br>");

//    var table = 12;
//    for(var a=1; a<11;a++){
//        document.write(table+"x "+a+" = "+a*table + "<br>")
//    }
//    document.write("<br>");

//    var table = 13;
//    for(var a=1; a<11;a++){
//        document.write(table+"x "+a+" = "+a*table + "<br>")
//    }
//    document.write("<br>");

//    var table = 14;
//    for(var a=1; a<11;a++){
//        document.write(table+"x "+a+" = "+a*table + "<br>")
//    }
//    document.write("<br>");

//    var table = 15;
//    for(var a=1; a<11;a++){
//        document.write(table+"x "+a+" = "+a*table + "<br>")
//    }
//    document.write("<br>");

//    var table = 16;
//    for(var a=1; a<11;a++){
//        document.write(table+"x "+a+" = "+a*table + "<br>")
//    }
//    document.write("<br>");

//    var table = 17;
//    for(var a=1; a<11;a++){
//        document.write(table+"x "+a+" = "+a*table + "<br>")
//    }
//    document.write("<br>");

//    var table = 18;
//    for(var a=1; a<11;a++){
//        document.write(table+"x "+a+" = "+a*table + "<br>");
//    }
//    document.write("<br>");

//    var table = 19;
//    for(var a=1; a<11;a++){
//        document.write(table+"x "+a+" = "+a*table + "<br>")
//    }
//    document.write("<br>");

//    var table = 20;
//    for(var a=1; a<11;a++){
//        document.write(table+"x "+a+" = "+a*table + "<br>")
//    }
//    document.write("<br>");






                      //Chapter 17-20.

//  1. Declare and initialize an empty multidimensional array.
//  (Array of arrays)

// var Arr=[[1,2],[3,4],[5,6]];

//  2. Declare and initialize a multidimensional array
//  representing the following matrix:

// var arry =[
//     [0,1,2,3],
//     [1,0,1,2],
//     [2,1,0,1],
// ]
// for (a = 0; a < arry.length; a++){
//     for(var b = 0; b < b.length; b++){
//         document.write(arry[a][b]+ " ");
//     }
//     document.write("<br>")
// }
// 3. Write a program to print numeric counting from 1 to 10.

// var array =[
//     [1],
//     [2],
//     [3],
//     [4],
//     [5],
//     [6],
//     [7],
//     [8],
//     [9],
//     [10],
// ] 
// for (a = 0; a < array.length; a++){
// document.write( array[a] +"<br>" );
// }


// 4. Write a program to print multiplication table of any
// number using for loop. Table number & length should be
// taken as an input from user.

// var table = prompt("Enter table number");
// var a = prompt( "Enter table lenght");
// for ( var i = 1; i <= a; i++){
// document.write(table + " * " + i +" " + "=" +" " + (i*table) + "<br>")
// }


// 5. Write a program to print items of the following array
// // using for loop:
// fruits = [“apple”, “banana”, “mango”, “orange”,
// “strawberry”]

// var fruits = ["Apple" , "Banana", "Mango" , "Orange" , "Strawberry"];
// for (var a =0; a < 5; a++ ){
//     document.write(fruits [a] + " " +"<br>");
//     }
//     document.write("<br>");
// for(var a = 0; a < 5; a++ ){
// document.write("Element at index" + " " + a + " " + "is" + " " + fruits[a] + "<br>" );
// }

// 6. Generate the following series in your browser. See
// example output.
// a. Counting: 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15

// document.write ("<h1>Counting:</h1>" );

// var counting = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15];
// document.write(counting);

// b. Reverse counting: 10, 9, 8, 7, 6, 5, 4, 3, 2, 1

// document.write ("<h1>Reverse Counting:</h1>" );

// var reverseCounting = [1,2,3,4,5,6,7,8,9,10];
// for (var a = 9; a >= 0; a--){
//     document.write(reverseCounting[a] + " ");
// }

// c. Even: 0, 2, 4, 6, 8, 10, 12, 14, 16, 18, 20

//  document.write ("<h1>Even:</h1>" );

//  var even = [2,4,6,8,10,12,14,16,18,20 ];
//  for(var a = 0; a < 10; a++){
//      document.write (even[a] + " ");
//  }

// for(i=2;i<=20;i+=2){
//     document.write(i)
// }

// d. Odd: 1, 3, 5, 7, 9, 11, 13, 15, 17, 19

//  
// e. Series: 2k, 4k, 6k, 8k, 10k, 12k, 14k, 16k, 18k, 20k

// document.write ("<h1>Series:</h1>" );

// var series = ["2k, 4k, 6k, 8k, 10k, 12k, 14k, 16k, 18k, 20k" ]
// document.write(series);


// 7. You have an array
// A = [“cake”, “apple pie”, “cookie”, “chips”, “patties”]
// Write a program to enable “search by user input” in an
// array.
// After searching, prompt the user whether the given item is
// found in the list or not. Example:

// var bakery = prompt ("Welcome to our Bakery Enter your oeder mame/sir");
// var A = ["cake", "apple pie", "cookie", "chips", "patties"];

// for( i = 0; i < A.length; i++){
//   if  (A[i] === bakery ){
   
// document.write ("availibale at "+i);
//   }
//   else{
// document.write("sorry mame/sir your order is not available" );
//   }
//   break
// }


// 8. Write a program to identify the largest number in the
// given array.
// A = [24, 53, 78, 91, 12].

// A = [24, 53, 78, 91, 12]
// var largest=A.sort();
// for (var i=0; i<4;i++){
//     if (A[i]>largest) {
//         var A=largest[i];   
//     }
// }
// document.write("A is" + A + "<br>" + "The largest number is" + " " + largest[i]);



// 9. Write a program to identify the smallest number in the
// given array.
// A = [24, 53, 78, 91, 12]

// var A = [24, 53, 78, 91, 12]

// A.sort()

// document.write(A[0])


// 10. Write a program to print multiples of 5 ranging 1 to
// 100.

// var a = 5;
// for (var i = 1; i <= 20; i++){
//     document.write(a * i +" ")
// }


                                       // Chapter 21-25

//   1. Write a program that takes two user inputs for first and
//   last name using prompt and merge them in a new variable
//   titled fullName. Greet the user using his full name.


// var firstName = prompt("Enter your first name ");
// var lastName = prompt("Enter your last name");
// var fullName = firstName + " " + lastName;
// document.write("Thanks to use your full name" + " " + fullName);


// 2. Write a program to take a user input about his favorite
// mobile phone model. Find and display the length of user
// input in your browser

// var input = prompt ("Enter your favorite mobile phone model");
// var str = input.length;
// document.write("My favorite mobile is" + " " + input + "<br>" + "Lenght of string" + " " + str );


// 3. Write a program to find the index of letter “n” in the word
// // “Pakistani” and display the result in your browser .
// var city = "Pakistani";
// var index =city.indexOf("n");
// document.write ("String:" + city + "<br>" + "<br>" +"index of n is "+ " "+ index);


// 4. Write a program to find the last index of letter “l” in the
// word “Hello World” and display the result in your browser.

//  var city = "Hello World";
//  var index =city.lastIndexOf("l");
//  document.write ("String:" + city + "<br>" + "<br>" +"index of l is "+ " "+ index);


// 5. Write a program to find the character at 3rd index in the
// word “Pakistani” and display the result in your browser.

// var str = "Pakistani";
// var index = str.charAt(3);
// document.write("String:" + " " + str + "<br>" + "Character of 3rd index is:" + " " + index );


// 6. Repeat Q1 using string concat() method.

// var firstName = prompt("Enter your first name ");
// var lastName = prompt("Enter your last name");
// var fullName = firstName.concat( " " + lastName);
// document.write("Thanks to use your full name" + " " + fullName);


// 7. Write a program to replace the “Hyder” to “Islam” in the
// word “Hyderabad” and display the result in your browser.

// var city = "Hyderabad";
// var c = city.replace("Hyder", "Islam")
// document.write(city + " <br>" + "After Replacment" + " " +c);


// 8. Write a program to replace all occurrences of “and” in the
// string with “&” and display the result in your browser.
// var message = “Ali and Sami are best friends. They play cricket and
// football together.”;

// var text = "“Ali and Sami are best friends. They play cricket and football together."
// var replace = text.replace(/and/g,"&");
// document.write(text + "<br>" +"<br>" + replace);


// 9. Write a program that converts a string “472” to a number
// 472. Display the values & types in your browser.

// var str = "472";
// var num = Number(str);
// document.write("Value:" + " " + str + "<br>" + "Type String" + "<br>" + "<br>" + "Value:" + " " + num + "<br>" + "Type Number" );

// 10. Write a program that takes user input. Convert and
// show the input in capital letters.

// var str = prompt ("Enter some thing");
// var a = str.toUpperCase();
// document.write(a);


// 11. Write a program that takes user input. Convert and
// show the input in title case.

// var str = prompt ("Enter some thing");
// var a = str[0].toUpperCase()
// var b=str.slice(1).toLowerCase()
// document.write("Usear input" + " " + str + "<br> "+ "Lowercase"+ " " +a+b);

// var a =prompt("enter")
// var b=a.split(' ')
// for(i=0;i<b.length;i++){
//     var c=b[i][0].toUpperCase()
//     var d=b[i].slice(1).toLowerCase()
//     document.write(c+d+" ")
// }


// 12. Write a program that converts the variable num to
// string.
// var num = 35.36 ;
// Remove the dot to display “3536” display in your browser.

//  var num = 35.36;
//  var result = parseInt(num);
//  document.write("Number" + " " + num + "<br>" + "<br>" + "Result" + " " + result );

// var num=35.36
// var a=num.toString()
// var b=a.replace('.','')
// console.log(b)

// 13. Write a program to take user input and store username
// in a variable. If the username contains any special symbol
// among [@ . , !], prompt the user to enter a valid username.
// For character codes of [@ .
// Note:
// ASCII code of ! is 33
// ASCII code of , is 44
// ASCII code of . is 46
// ASCII code of @ is 64

// var fullName = prompt('Enter your full name');
// var correct_way = /^[A-Za-z]+$/;

// if (fullName.match(correct_way)){
//     alert(fullName)
// }
// else{
//     alert ('Please enter correct user name');
// }

// var a=prompt('enter')
// var b=a.match("@")
// if(b){
//     alert("correct")
// }


// 14. You have an array
// A = [cake”, “apple pie”, “cookie”, “chips”, “patties”]
// Write a program to enable “search by user input” in an
// array. After searching, prompt the user whether the given
// item is found in the list or not.
// Note: Perform case insensitive search. Whether the user
// enters cookie, Cookie, COOKIE or coOkIE, program
// should inform about its availability.

// var bakery = prompt("Enter your order mame/sir");
// var array = ["cake", "apple pie", "cookie", "chips", "patties"];
// var a=array.indexOf(bakery)
// if(a>=0){
//     alert(bakery+" is avaliable "+a+" index")
// }else{
//     alert("it's not avaliable")
// }

// 15. Write a program to take password as an input from
// user. The password must qualify these requirements:
// a. It should contain alphabets and numbers
// b. It should not start with a number
// c. It must at least 6 characters long
// If the password does not meet above requirements,
// prompt the user to enter a valid password.
// For character codes of a-z, A-Z & 0-9, refer to ASCII
// table at the end of this document.

// var a=prompt("enter")
// var b=/^[A-Za-z]+$/
// var c=new RegExp('(?=.*[0-9])')
// if(c.test(a)){
//     alert("okay")
// }

// 16. Write a program to convert the following string to an
// array using string split method.
// var university = “University of Karachi”;
// Display the elements of array in your browser.

// var university = "University of Karachi";
// var a = university.split("");
// for (var i=0; i<a.length; i++){
// document.write(a[i] + "<br>")
// }


// 17. Write a program to display the last character of a user
// input.

// var input = prompt("Enter some thing");
// document.write(input + " " + "<br>" + "last character is" + " " +  input.slice(-1) );


// 18. You have a string “The quick brown fox jumps over the
// lazy dog”. Write a program to count number of
// occurrences of word “the” in given string.

// var txt = "“the quick brown fox jumps over the lazy dog”.";
// var count = (txt.match(/the/g) || []).length;
// document.write("Text:" + " " + txt + "<br>" + "There are " + " " + count  + " " + "occurrences of word “the”" );

var a =prompt("enter")
var b=a.split(' ')
for(i=0;i<b.length;i++){
    var c=b[i][0].toUpperCase()
    var d=b[i].slice(1).toLowerCase()
    document.write(c+d+" ")
}


